package com.example.oddjobs;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PostViewHolder extends RecyclerView.ViewHolder {

    TextView task_title_view,description_view ,city_view,contact_phonenumber_view,
            contact_email_view, listers_email_view,est_payment_view;

    public PostViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {

        super(itemView);
        task_title_view = itemView.findViewById(R.id.post_task_title);
        description_view = itemView.findViewById(R.id.post_city);
        city_view = itemView.findViewById(R.id.post_city);
        contact_email_view = itemView.findViewById(R.id.post_contact_email);
        contact_phonenumber_view = itemView.findViewById(R.id.post_contact_phonenumber);
        listers_email_view = itemView.findViewById(R.id.post_listers_email);
        est_payment_view = itemView.findViewById(R.id.post_est_payment);

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (recyclerViewInterface != null)
                {
                    int pos = getAdapterPosition();
                    if(pos!= RecyclerView.NO_POSITION)
                    {
                        recyclerViewInterface.onItemClick(pos);
                    }
                }
            }
        });

    }

}