package com.example.oddjobs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.nio.Buffer;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CreatePost extends AppCompatActivity {

    String user_email;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);
        user_email =  getIntent().getStringExtra("user_email");
        Button create_post = (Button) findViewById(R.id.btn_submit_post);
        create_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createPostInDB(user_email);
                recreate();
            }
        });

    }

    public boolean validateInput(String task_title,String description,String city,String contact_phone,String contact_email,String est_payment){
        boolean valid = true;
        if(task_title.equals("") || description.equals("") || city.equals("") || contact_phone.equals("") || contact_email.equals("") || est_payment.equals("")){
            Toast.makeText(getApplicationContext(), "Please ensure you entered all details correctly.", Toast.LENGTH_LONG).show();
            valid = false;
        }
        return valid;
    }

    public void back(View view){
        Intent i = new Intent(CreatePost.this, Dashboard.class);
        i.putExtra("user_email",user_email);
        startActivity(i);

    }
    public void  createPostInDB(String inEmail)
    {
        String task_title = ((EditText) findViewById(R.id.edit_task_title)).getText().toString();
        String description = ((EditText) findViewById(R.id.edit_description)).getText().toString();
        String city = ((EditText) findViewById(R.id.edit_city)).getText().toString();
        String contact_phone = ((EditText) findViewById(R.id.edit_contact_phonenumber)).getText().toString();
        String contact_email = ((EditText) findViewById(R.id.edit_contact_email)).getText().toString();
        String est_payment = ((EditText) findViewById(R.id.edit_est_payment)).getText().toString();
        String est_payment_str = String.valueOf(est_payment);

        if(validateInput(task_title,description,city,contact_phone,contact_email,est_payment)){

        OkHttpClient client = new OkHttpClient();
        RequestBody credentialsBody = new FormBody.Builder()
                .add("task_title",task_title)
                .add("description",description)
                .add("city",city)
                .add("contact_phone",contact_phone)
                .add("contact_email", contact_email)
                .add("est_payment", est_payment_str)
                .add("listers_email", inEmail)
                .build();
        Request request = new Request.Builder().url("https://lamp.ms.wits.ac.za/home/s2555154/create_post.php").post(credentialsBody).build();
        System.out.println("cred:"+credentialsBody.toString());
        System.out.println(task_title+" "+user_email+" "+inEmail+" "+est_payment_str+" "+city+" "+contact_email+" "+contact_phone);

// Print the RequestBody


        client.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
                System.out.println(e.toString());
            }
            public void onResponse(Call call, Response response) throws IOException {
                CreatePost.this.runOnUiThread(new Runnable() {
                    public void run() {
                        System.out.println(response);
                        // Reset the EditText views to empty strings
                        ((EditText) findViewById(R.id.edit_task_title)).setText("");
                        ((EditText) findViewById(R.id.edit_description)).setText("");
                        ((EditText) findViewById(R.id.edit_city)).setText("");
                        ((EditText) findViewById(R.id.edit_contact_phonenumber)).setText("");
                        ((EditText) findViewById(R.id.edit_contact_email)).setText("");
                        ((EditText) findViewById(R.id.edit_est_payment)).setText("");

                    }
                });
            }
        });}
    }
    // The bodyToString method can be defined as follows:

}