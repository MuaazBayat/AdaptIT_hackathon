package com.example.oddjobs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Signup extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        TextView to_login_screen = (TextView)findViewById(R.id.signupScreen_login_btn);
        Button sign_up_btn = (Button) findViewById(R.id.signupScreen_signup_btn);

        to_login_screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Signup.this, MainActivity.class);
                startActivity(intent);
            }
        });
        sign_up_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String email = ((EditText) findViewById(R.id.signupScreen_email_txt_inpt)).getText().toString();
                String password = ((EditText) findViewById(R.id.sinupScreen_password_inpt)).getText().toString();
                String confirmPassword = ((EditText) findViewById(R.id.sinupScreen_cpassword_inpt)).getText().toString();
                if (confirmPassword.equalsIgnoreCase(password))
                {
                    if(!validateInput(email,password,confirmPassword)){
                       return;
                    }
                    fillUserDetails(email,password);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Passwords do not match :(", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    public void fillUserDetails(String inEmail, String inPassword){
        OkHttpClient client = new OkHttpClient();
        RequestBody credentialsBody = new FormBody.Builder().add("uemail",inEmail).build();
        Request request = new Request.Builder().url("https://lamp.ms.wits.ac.za/home/s2555154/get_users.php").post(credentialsBody).build();
        client.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
                System.out.println(e.toString());
            }
            public void onResponse(Call call, Response response) throws IOException {
                final String responseData = response.body().string();
                Signup.this.runOnUiThread(new Runnable() {
                    public void run() {
                        System.out.println(responseData);
                        if (responseData.length()==2)
                        {
                            insertUserInDB(inEmail,inPassword);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Email already exists, try logging in", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }
    public void insertUserInDB(String inEmail, String inPassword) {
        OkHttpClient client = new OkHttpClient();
        RequestBody credentialsBody = new FormBody.Builder()
                .add("email", inEmail)
                .add("password", inPassword)
                .build();
        System.out.println(inEmail+" "+inPassword);
        Request request = new Request.Builder().url("https://lamp.ms.wits.ac.za/home/s2555154/create_user.php").post(credentialsBody).build();
        System.out.println(credentialsBody);
        client.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
                System.out.println(e.toString());
            }
            public void onResponse(Call call, Response response) throws IOException {
                Signup.this.runOnUiThread(new Runnable() {
                    public void run() {
                        System.out.println(response);
                        Intent intent = new Intent(Signup.this, Dashboard.class);
                        intent.putExtra("user_email",inEmail);
                        startActivity(intent);
                    }
                });
            }
        });
    }

    public boolean validateInput(String email, String password, String password_confirm){
        boolean valid = true;
        if(email.equals("") || password.equals("") || password_confirm.equals("")){
            Toast.makeText(getApplicationContext(), "Please ensure you entered all details correctly.", Toast.LENGTH_LONG).show();
            valid = false;
        }

            return valid;
    }


}