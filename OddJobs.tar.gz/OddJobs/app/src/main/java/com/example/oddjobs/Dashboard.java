package com.example.oddjobs;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Dashboard extends AppCompatActivity implements RecyclerViewInterface{
    String user_email;
    String post_ID;
    List<Post> Posts = new ArrayList<>();
    String responsesData = "";
    RecyclerView recyclerView;
    PostAdapter postAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        user_email =  getIntent().getStringExtra("user_email");
        System.out.println("Signed in as: "+user_email);

        getPostsJSON(user_email);

        recyclerView = findViewById(R.id.post_recycler_view);
        //postAdapter = new PostAdapter(Posts, PostFeed.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        postAdapter = new PostAdapter(getApplicationContext(), Posts, this);
        recyclerView.setAdapter(postAdapter);
        System.out.println(Posts);

        FloatingActionButton create_post  = (FloatingActionButton) findViewById(R.id.to_create_post_btn);
        create_post.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this,CreatePost.class );
                intent.putExtra("user_email", user_email);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onItemClick(int position) {
        /*
        Intent intent = new Intent(Dashboard.this,thread.class);
        intent.putExtra("post_title", Posts.get(position).getPost_title());
        intent.putExtra("signed_email",user_email);
        startActivity(intent);

         */
    }
    public void getPostsJSON(String inEmail){
        OkHttpClient client = new OkHttpClient();
        RequestBody credentialsBody = new FormBody.Builder().add("uemail",inEmail).build();
        Request request = new Request.Builder().url("https://lamp.ms.wits.ac.za/home/s2555154/get_listings.php").post(credentialsBody).build();
        client.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
                System.out.println(e.toString());
            }
            public void onResponse(Call call, Response response) throws IOException {
                final String responseData = response.body().string();
                Dashboard.this.runOnUiThread(new Runnable() {
                    public void run() {
                        responsesData = responseData;
                        System.out.println(responseData);
                        JSONArray jsonArray = null;
                        try {
                            jsonArray = new JSONArray(responseData);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String task_title = jsonObject.getString("task_title");
                                String description = jsonObject.getString("description");
                                String city = jsonObject.getString("city");
                                String contact_phonenumber = jsonObject.getString("contact_phonenumber");
                                String contact_email = jsonObject.getString("contact_email");
                                String listers_email = jsonObject.getString("listers_email");
                                Double est_payment = Double.parseDouble(jsonObject.getString("est_payment"));

                                // Create a new Post object and add it to the Posts list
                                Posts.add(new Post(task_title, description, city, contact_phonenumber, contact_email, listers_email, est_payment));
                            }
                            if (Posts.size()==0)
                            {
                                Toast.makeText(getApplicationContext(), "You have made no listings", Toast.LENGTH_LONG).show();

                            }
                            // orderByUpVotes();
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }

                        //Toast.makeText(getApplicationContext(),inPasswordInput,Toast.LENGTH_LONG).show();
                    }


                });
            }
        });
    }


    public void convertJsonToPostList(String jsonString) throws JSONException {
        JSONArray jsonArray = new JSONArray(jsonString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String task_title = jsonObject.getString("task_title");
            String description = jsonObject.getString("description");
            String city = jsonObject.getString("city");
            String contact_phonenumber = jsonObject.getString("contact_phonenumber");
            String contact_email = jsonObject.getString("contact_email");
            String listers_email = jsonObject.getString("listers_email");
            Double est_payment = jsonObject.getDouble("est_payment");

            // Create a new Post object and add it to the Posts list
            Posts.add(new Post(task_title, description, city, contact_phonenumber, contact_email, listers_email, est_payment));
        }
    }


}