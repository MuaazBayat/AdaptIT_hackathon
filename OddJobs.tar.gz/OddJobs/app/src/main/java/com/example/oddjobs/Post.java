package com.example.oddjobs;

public class Post {
    String task_title, description, province, city, contact_phonenumber, contact_email, listers_email;
    Double est_payment;
    // Parameterized constructor
    public Post(String task_title, String description, String city,
                String contact_phonenumber, String contact_email, String listers_email, Double est_payment) {
        this.task_title = task_title;
        this.description = description;
        this.city = city;
        this.contact_phonenumber = contact_phonenumber;
        this.contact_email = contact_email;
        this.listers_email = listers_email;
        this.est_payment = est_payment;
    }

    // Getter and Setter methods for all fields
    public String getTask_title() {
        return task_title;
    }

    public void setTask_title(String task_title) {
        this.task_title = task_title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContact_phonenumber() {
        return contact_phonenumber;
    }

    public void setContact_phonenumber(String contact_phonenumber) {
        this.contact_phonenumber = contact_phonenumber;
    }

    public String getContact_email() {
        return contact_email;
    }

    public void setContact_email(String contact_email) {
        this.contact_email = contact_email;
    }

    public String getListers_email() {
        return listers_email;
    }

    public void setListers_email(String listers_email) {
        this.listers_email = listers_email;
    }

    public Double getEst_payment() {
        return est_payment;
    }

    public void setEst_payment(Double est_payment) {
        this.est_payment = est_payment;
    }
}