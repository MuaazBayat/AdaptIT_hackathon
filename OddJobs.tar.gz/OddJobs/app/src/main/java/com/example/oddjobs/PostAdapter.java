package com.example.oddjobs;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostViewHolder> {
    private final RecyclerViewInterface recyclerViewInterface;
    Context context;
    List<Post> Posts;
    //RecyclerViewInterface recyclerViewInterface
    public PostAdapter(Context context, List<Post> Posts, RecyclerViewInterface recyclerViewInterface) {
        this.recyclerViewInterface = recyclerViewInterface;
        this.context = context;
        this.Posts = Posts;
    }

    @NonNull
    @Override
    //,recyclerViewInterface
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new PostViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_post,parent,false), recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        holder.task_title_view.setText(Posts.get(position).getTask_title());
        holder.description_view.setText(Posts.get(position).getDescription());
        holder.city_view.setText(Posts.get(position).getCity());
        holder.contact_phonenumber_view.setText(Posts.get(position).getContact_phonenumber());
        holder.contact_email_view.setText(Posts.get(position).getContact_email());
        holder.listers_email_view.setText(Posts.get(position).getListers_email());
        holder.est_payment_view.setText(Double.toString(Posts.get(position).getEst_payment()));

    }

    @Override
    public int getItemCount() {
        return Posts.size();
    }
}