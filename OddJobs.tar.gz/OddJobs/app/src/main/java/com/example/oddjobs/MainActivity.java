package com.example.oddjobs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import android.widget.Button;


public class MainActivity extends AppCompatActivity
{
    String user_email;
    protected void onCreate(Bundle savedInstanceState)
    {
        //set xml layout
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //assigns xml id's to buttons
        Button login = (Button) findViewById(R.id.login_btn);
        Button sign_up = (Button) findViewById(R.id.signup_btn);

        //set button on click to go to sign up screen
        sign_up.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showSignUpScreen();
            }
        });

        //sets button on click for logging in
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String user_email_inpt = ((EditText) findViewById(R.id.email_txt)).getText().toString();
                String user_password_inpt = ((EditText) findViewById(R.id.password_txt)).getText().toString();
                user_email = user_email_inpt;
                if(validateInput(user_email,user_password_inpt)){
                authenticate(user_email_inpt,user_password_inpt);}
            }
        });
    }

    public void showSignUpScreen()
    {
        Intent intent = new Intent(MainActivity.this,Signup.class);
        startActivity(intent);
    }
    public void showUsersPostsScreen()
    {
        Intent intent = new Intent(MainActivity.this,Dashboard.class);
        intent.putExtra("user_email", user_email);
        startActivity(intent);
    }
    public void authenticate(String inEmail,String inPasswordInput)
    {
        OkHttpClient client = new OkHttpClient();
        RequestBody credentialsBody = new FormBody.Builder().add("uemail",inEmail).build();
        Request request = new Request.Builder().url("https://lamp.ms.wits.ac.za/home/s2555154/get_password.php").post(credentialsBody).build();
        client.newCall(request).enqueue(new Callback() {
            public void onFailure(Call call, IOException e) {
                System.out.println(e.toString());
            }
            public void onResponse(Call call, Response response) throws IOException {
                final String responseData = response.body().string();
                MainActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        /*
                        Toast.makeText(getApplicationContext(),inPasswordInput,Toast.LENGTH_LONG).show();
                        System.out.println("In:"+inPasswordInput);
                        System.out.println("In:"+extractPassword(responseData));
                        */
                        System.out.println("In:"+extractPassword(responseData));
                        if(extractPassword(responseData).equals(inPasswordInput))
                        {
                            showUsersPostsScreen();
                            System.out.println("can move on");
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Email or password is incorrect!",Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }
    public String extractPassword(String json)
    {
        try {
            JSONArray all = new JSONArray(json);
            JSONObject item = all.getJSONObject(0);
            String password = item.getString("password");
            return password;
        } catch (JSONException e)
        {
            e.printStackTrace();
        }
        return "";
    }

    public boolean validateInput(String email, String password){
        boolean valid = true;
        if(email.equals("") || password.equals("")){Toast.makeText(getApplicationContext(), "Please ensure you entered all details correctly.", Toast.LENGTH_LONG).show();

            valid = false;
        }
        return valid;
    }
}