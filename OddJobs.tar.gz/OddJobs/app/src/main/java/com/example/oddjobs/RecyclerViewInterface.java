package com.example.oddjobs;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}